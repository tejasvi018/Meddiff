The enviroment used in the Q1 to Q4 are:
Sublime text- code editor.
Command Line- to run py and create virtual enviroment.