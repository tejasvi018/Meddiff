import os

filePath = r"C:\Users\Vishwas Singla\Desktop\Tejasvi\Logs\logFile.txt"

logFile = open(filePath,"r")
fileName = os.path.basename(filePath)
folderPath = os.path.dirname(filePath)


errorFilePath = os.path.join(folderPath,"error_"+fileName)
errorFile = open(errorFilePath,"w")
warningFilePath = os.path.join(folderPath,"warning_"+fileName)
warningFile = open(warningFilePath,"w")


for line in logFile.readlines():
    
    if "ERROR" in line.split(" "):
        errorFile.write(line+"\n")
        
    if "WARNING" in line.split(" "):
        warningFile.write(line+"\n")
  
        
logFile.close()
errorFile.close()
warningFile.close()
