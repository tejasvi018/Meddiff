class Path:
    
    def __init__(self,path):
        
        self.current_path = "/"
        self.rootDirs = []
        self.dirSize = 0
            
            
        dirs = path.split("/")
        for dirVal in dirs:
            
            if dirVal.isalpha() or dirVal=='':
                self.rootDirs.append(dirVal)
                self.dirSize = self.dirSize+1
            elif dirVal==".." and self.dirSize!=0:
                self.rootDirs.pop()
                self.dirSize = self.dirSize-1
            else:
                self.current_path = None
                self.rootDirs = None
                break
            
        if self.current_path is not None:
            self.current_path = self.current_path.join(self.rootDirs)
        
    def cd(self,path):
        
        if(path[0]=="/"):
            self.current_path = "/"
            self.rootDirs = []
            self.dirSize = 0
            
        dirs = path.split("/")
        
        for dirVal in dirs:
            
            if dirVal.isalpha() or dirVal=='':
                self.rootDirs.append(dirVal)
                self.dirSize = self.dirSize+1
            elif dirVal==".." and self.dirSize!=0:
                self.rootDirs.pop()
                self.dirSize = self.dirSize-1
            else:
                self.current_path = None
                self.rootDirs = None
                break
            
        if self.current_path is not None:
            self.current_path = "/"
            self.current_path = self.current_path.join(self.rootDirs)
        
        
path = Path("/a/b/x/d")

path.cd('/x')

print(path.current_path)
