The enivroment used in this question is:
Sublime Text
Cmd
Py 3.7
pip
pandas

The assumption made in this question are:
Roll Number is taken as unique key.The operations update, insert, delete and search are perfomed taking the roll number as unique key.