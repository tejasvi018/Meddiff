from django import forms

from .models import Post

class dataForm(forms.Form):

    Name = forms.CharField()
    RollNumber = forms.CharField()
    Age = forms.IntegerField()
    Gender = forms.CharField()

class SUDForm(forms.Form):

    RollNumber = forms.CharField()
    
