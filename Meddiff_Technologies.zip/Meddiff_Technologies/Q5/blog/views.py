from django.shortcuts import render
from .models import Post
from .forms import PostForm
import pandas as pd



databasePath= r"C:\Users\Tejasvi Meharda\Desktop\Database.csv"
df = pd.DataFrame(columns=['Name','Age','RollNumber','Gender'])
df.to_csv(databasePath)

def insertData(request):
    if request.method == "POST":
    	name = request.POST['Name']
    	age = request.POST['Age']
    	rollNumber = request.POST['RollNumber']
    	gender = request.POST['Gender']
    	df.loc[len(df.index)] = [name, age, rollNumber, gender]
    	df.to_csv(databasePath)
    	#return render(request, 'blog/homePage.html', context)

    #else:	
    	#form=dataForm()
    	#return render(request, 'blog/insertData.html', {'form': form})
    form=dataForm()
    return render(request, 'blog/insertData.html', {'form': form})



def searchData(request):
	if request.method == "POST":
    	rollNumber = request.POST['RollNumber']
    	searched_data=df.loc[df['RollNumber'] == rollNumber]
    	print(searched_data)
    	context = {'database': searched_data, 'message':"SEARCH DONE"}
    	#return render(request, 'blog/homePage.html', context)

    #else:
    	#form=SUDForm()
    	#return render(request, 'blog/searchData.html', {'form': form})
    form=dataForm()
    return render(request, 'blog/insertData.html', {'form': form})
    	

def updateData(request):
	if request.method == "POST":
		name = request.POST['Name']
    	age = request.POST['Age']
    	rollNumber = request.POST['RollNumber']
    	gender = request.POST['Gender']
    	index=df.loc[df['RollNumber'] == rollNumber].index[0]
    	df.loc[index] = [name, age, rollNumber, gender]
    	df.to_csv(databasePath)
    	update_data=df.loc[df['RollNumber'] == rollNumber]
    	context = {'database': update_data, 'message':"Update DONE"}
    	#return render(request, 'blog/homePage.html', context)

    #else:
    	#form=SUDForm()
    	#return render(request, 'blog/updateData.html', {'form': form})
    form=dataForm()
    return render(request, 'blog/insertData.html', {'form': form})

def deleteData(request):
	if request.method == "POST":
    	rollNumber = request.POST['RollNumber']
    	index=df.loc[df['RollNumber'] == rollNumber].index[0]
    	df = df.drop([index])
    	df.to_csv(databasePath)
    	#return render(request, 'blog/homePage.html', context)

    #else:
    	#form=SUDForm()
    	#return render(request, 'blog/deleteData.html', {'form': form})
    form=dataForm()
    return render(request, 'blog/insertData.html', {'form': form})
    	
#def homePage(request):
	#return render(request, 'blog/homePage.html', {})	

