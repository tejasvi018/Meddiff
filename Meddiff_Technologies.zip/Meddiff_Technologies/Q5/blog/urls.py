from django.urls import path
from . import views

urlpatterns = [
	#path('', views.homePage, name='homePage'),
    path('insert/', views.insertData, name='insertData'),
    path('search/', views.searchtData, name='searchData'),
    path('update/', views.updateData, name='updateData'),
    path('delete/', views.deleteData, name='deleteData'),
]