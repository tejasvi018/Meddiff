def groupByOwner(fileDict):
    
    outputDict = {}
    for key,value in fileDict.items():
        
        if value in outputDict.keys():
            outputDict[value].append(key)
        else:
            outputDict[value] = [key]
            
    return outputDict


d = {'Input.txt': 'Randy', 'Code.py': 'Stan', 'Output.txt': 'Randy'}

dOut = groupByOwner(d)